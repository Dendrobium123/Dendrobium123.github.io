---
title: 第一篇博客
description: 不知道写什么
slug: hello-world
date: 2024-02-23T15:46:50+08:00
image: http://tuchuang.dendrobiumcgk.chat/pic/cover2.jpg
categories:
    - 阿米诺斯
tags:
    - 阿米诺斯   
---

## *我只想说，做blog好难，尤其是对我这种毫无经验的若至来说*

markdown语法现在也没研究明白，不知道要怎么弄

第一次发博客就随便放两张我们胡桃的照片好了，啊~真可爱啊。

![](http://tuchuang.dendrobiumcgk.chat/pic/VRChat_2024-01-22_00-01-45.608_2560x1440.jpg)

![](http://tuchuang.dendrobiumcgk.chat/pic/VRChat_2024-01-21_23-46-55.640_2560x1440.jpg)